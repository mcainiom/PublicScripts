#!/bin/bash

#  TerminateScript.sh
#  
#
#  Created by Mark Cain on 27/01/2023.
#
# function to remove Octory after user finishes onboarding

# Standard Variables
targetdir="/Library/Application Support/Octory"                 # Installation directory
appname="OctoryCleanup"                                                # Name of application to display in the logs
logandmetadir="/Library/Logs/Microsoft/IntuneScripts"    # Log file directory

# Generated variables
tempdir=$(mktemp -d)                                            # Temp directory
tempfile="/$tempdir/octory.zip"                                 # Temp file
log="$logandmetadir/$appname.log"                               # Log file name
consoleuser=$(ls -l /dev/console | awk '{ print $3 }')          # Current user
userdockplist="/Users/$consoleuser/Library/Preferences/com.apple.dock.plist"
userhome="/Users/$consoleuser"
loggedInUser=$( echo "show State:/Users/ConsoleUser" | scutil | awk '/Name :/ && ! /loginwindow/ { print $3 }' )
loggedInUID=`id -u ${loggedInUser}`
if [[ -a "/System/Applications/System Settings.app" ]]; then settingsApp="System Settings.app"; else settingsApp="System Preferences.app"; fi
if [[ -a "/System/Volumes/Preboot/Cryptexes/App/System/Applications/Safari.app" ]];
        then safari="/System/Volumes/Preboot/Cryptexes/App/System/Applications/Safari.app"; else safari="/Applications/Safari.app"; fi


dockapps=( "/System/Applications/Launchpad.app"
            "$safari"
            "/Applications/Google Chrome.app"
            "/Applications/Microsoft Outlook.app"
            "/Applications/Microsoft Word.app"
            "/Applications/Microsoft Excel.app"
            "/Applications/Microsoft PowerPoint.app"
            "/Applications/Microsoft OneNote.app"
            "/Applications/Microsoft Teams.app"
            "/Applications/Company Portal.app"
            "/System/Applications/$settingsApp")
            
# Uncomment these lines if you want to add network shares to the Dock

#netshares=(   "smb://192.168.0.12/Data"
#              "smb://192.168.0.12/Home"
#              "smb://192.168.0.12/Tools")
            

## Check if the log directory has been created
if [ -d $logandmetadir ]; then
    ## Already created
    echo "$(date) | Log directory already exists - $logandmetadir"
else
    ## Creating Metadirectory
    echo "$(date) | creating log directory - $logandmetadir"
    mkdir -p $logandmetadir
fi

cleanup() {

    cd "$HOME"

    if [ -d "$tempdir" ]; then
        echo "$(date) | Cleanup - Removing temp directory [$tempdir]"
        rm -rf "$tempdir"
    fi

    if [ -d "$targetdir" ]; then
        ## Octory directory already exists, we need to remove it
        echo "$(date) | Cleanup - Removing target directory [$targetdir]"
        rm -rf "$targetdir"
    fi

    ## Remove octo-notifier
    rm -rf /usr/bin/local/octo-notifier

    ## Remove Helper
/bin/launchctl bootout system /Library/LaunchDaemons/com.amaris.octory.helper.plist
/bin/rm /Library/LaunchDaemons/com.amaris.octory.helper.plist
/bin/rm /Library/PrivilegedHelperTools/com.amaris.octory.helper

# Unload Octory Agent
loggedInUser=$( echo "show State:/Users/ConsoleUser" | scutil | awk '/Name :/ && ! /loginwindow/ { print $3 }' )
loggedInUID=$(/usr/bin/id -u ${loggedInUser})

/bin/launchctl bootout gui/${loggedInUID}/ /Library/LaunchAgents/com.amaris.octory.launch.plist

# Remove Launch Agent
/bin/rm /Library/LaunchAgents/com.amaris.octory.launch.plist

}
# start logging
exec &> >(tee -a "$log")

echo "$(date) |  Removing Dock Persistent Apps"
defaults delete $userdockplist persistent-apps
#defaults delete $userdockplist persistent-others

echo "$(date) |  Adding Apps to Dock"
for i in "${dockapps[@]}"; do
  if [[ -a "$i" ]] ; then
    echo "$(date) |  Adding [$i] to Dock"
    defaults write $userdockplist persistent-apps -array-add "<dict><key>tile-data</key><dict><key>file-data</key><dict><key>_CFURLString</key><string>$i</string><key>_CFURLStringType</key><integer>0</integer></dict></dict></dict>"
  fi
done

#if [[ "$netshares" ]]; then
#  echo "$(date) |  Adding Network Shares to Dock"
#  for j in "${netshares[@]}"; do
#      label="$(basename $j)"
#      echo "$(date) |  Adding [$j][$label] to Dock"
#      defaults write $userdockplist persistent-others -array-add "<dict><key>tile-data</key><dict><key>label</key><string>$label</string><key>url</key><dict><key>_CFURLString</key><string>$j</string><key>_CFURLStringType</key><integer>15</integer></dict></dict><key>tile-type</key><string>url-tile</string></dict>"

#  done
#fi

#echo "$(date) | Adding Downloads Stack"
#consoleuser=$(ls -l /dev/console | awk '{ print $3 }')
#downloadfolder="$userhome/Downloads"
#defaults write $userdockplist persistent-others -array-add "<dict><key>tile-data</key><dict><key>file-data</key><dict><key>_CFURLString</key><string>$downloadfolder</string><key>_CFURLStringType</key><integer>0</integer></dict><key>file-label</key><string>Downloads</string><key>file-type</key><string>2</string></dict><key>tile-type</key><string>directory-tile</string></dict>"

chown -R $consoleuser $userdockplist

echo "$(date) | Restarting Dock"
killall Dock

# Change Default Mail Client to Outlook
sudo /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/microsoft/shell-intune-samples/master/macOS/Apps/Office%20for%20Mac/Outlook/setOutlookasDefaultMailClient.sh)"

#  echo "$(date) | Launching OneDrive for [$loggedInUser]"
su $loggedInUser -c "open /Applications/OneDrive.app"

touch "/Users/$loggedInUser/Library/Preferences/.OctoryDone"

cleanup
