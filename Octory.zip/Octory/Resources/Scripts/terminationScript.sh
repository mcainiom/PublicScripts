#!/bin/bash

#  TerminateScript.sh
#  
#
#  Created by Mark Cain on 27/01/2023.
#
# function to remove Octory after user finishes onboarding

# Standard Variables
targetdir="/Library/Application Support/Octory"                 # Installation directory
appname="OctoryCleanup"                                                # Name of application to display in the logs
logandmetadir="/Library/Logs/Microsoft/IntuneScripts"    # Log file directory

# Generated variables
tempdir=$(mktemp -d)                                            # Temp directory
tempfile="/$tempdir/octory.zip"                                 # Temp file
log="$logandmetadir/$appname.log"                               # Log file name
consoleuser=$(ls -l /dev/console | awk '{ print $3 }')          # Current user

## Check if the log directory has been created
if [ -d $logandmetadir ]; then
    ## Already created
    echo "$(date) | Log directory already exists - $logandmetadir"
else
    ## Creating Metadirectory
    echo "$(date) | creating log directory - $logandmetadir"
    mkdir -p $logandmetadir
fi

cleanup() {

    cd "$HOME"

    if [ -d "$tempdir" ]; then
        echo "$(date) | Cleanup - Removing temp directory [$tempdir]"
        rm -rf "$tempdir"
    fi

    ## Remove Agent
/bin/launchctl bootout system /Library/LaunchDaemons/com.amaris.octory.helper.plist
/bin/rm /Library/LaunchDaemons/com.amaris.octory.helper.plist
/bin/rm /Library/PrivilegedHelperTools/com.amaris.octory.helper


    if [ -d "$targetdir" ]; then
        ## Octory directory already exists, we need to remove it
        echo "$(date) | Cleanup - Removing target directory [$targetdir]"
        rm -rf "$targetdir"
    fi

    ## Remove octo-notifier
    rm -rf /usr/bin/local/octo-notifier
}
# start logging
exec &> >(tee -a "$log")

#Clear current Dock and add our items
/usr/local/bin/dockutil --remove all --allhomes --no-restart
/usr/local/bin/dockutil --add /System/Applications/Launchpad.app --allhomes --no-restart
/usr/local/bin/dockutil --add /Applications/Safari.app --allhomes --no-restart
/usr/local/bin/dockutil --add '/Applications/Google Chrome.app' --allhomes --no-restart
/usr/local/bin/dockutil --add '/Applications/Microsoft Excel.app' --allhomes --no-restart
/usr/local/bin/dockutil --add '/Applications/Microsoft Outlook.app' --allhomes --no-restart
/usr/local/bin/dockutil --add '/Applications/Microsoft OneNote.app' --allhomes --no-restart
/usr/local/bin/dockutil --add '/Applications/Microsoft PowerPoint.app' --allhomes --no-restart
/usr/local/bin/dockutil --add '/Applications/Microsoft Word.app' --allhomes --no-restart
/usr/local/bin/dockutil --add '/Applications/Microsoft Teams.app' --allhomes --no-restart
#/usr/local/bin/dockutil --add /Applications/Pages.app --allhomes --no-restart
#/usr/local/bin/dockutil --add /Applications/Numbers.app --allhomes --no-restart
#/usr/local/bin/dockutil --add /Applications/Keynote.app --allhomes --no-restart
/usr/local/bin/dockutil --add '/Applications/Company Portal.app' --allhomes --no-restart
/usr/local/bin/dockutil --add '/System/Applications/System Preferences.app' --allhomes
/usr/bin/killall Dock

loggedInUser=$( echo "show State:/Users/ConsoleUser" | scutil | awk '/Name :/ && ! /loginwindow/ { print $3 }' )

#  echo "$(date) | Launching OneDrive for [$loggedInUser]"
su $loggedInUser -c "open /Applications/OneDrive.app"

touch "/Users/$loggedInUser/Library/Preferences/.OctoryDone"

cleanup
